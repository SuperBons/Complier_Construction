#include <stdio.h>
#define read(x) scanf("%d",&x)
#define write(x) printf("%d\n",x)

void cse141foo( ) {
    int cse141a;
    read(cse141a) ;
    write(cse141a) ;
}

int main( ) {
  cse141foo( ) ;
}
