#include <stdio.h>
#define read(x) scanf("%d\n", &x)
#define write(x) printf("%d\n", x)
// function foo
void cse141foo() {
    int cse141a;
    read(cse141a);
    write(cse141a);
    cse141lmao; 
}

int main() {
    cse141foo();
}