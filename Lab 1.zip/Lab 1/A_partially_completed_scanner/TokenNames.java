/**
 * A enum of the token names
 */

/**
 * @author Danny Reinheimer
 *z
 */
public enum TokenNames {
	Identifiers, Numbers, ReserveWord, Symbol, String,
	MetaStatements, None, Space

}
