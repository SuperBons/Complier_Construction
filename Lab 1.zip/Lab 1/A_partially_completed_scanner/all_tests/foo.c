#include <stdio.h>
#define read(x) scanf("%d\n", &x)
#define write(x) printf("%d\n", x)
// function foo
void foo() {
    int a;
    read(a);
    write(a);
    lmao; 
}

int main() {
    foo();
}